package com.example.ca3



data class Coffee(
    val id: Int,
    val name: String,
    val price: Double
)
