package com.example.ca3

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ca3.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)

        binding.btnAddCoffee.setOnClickListener {
            val name = binding.etCoffeeName.text.toString()
            val price = binding.etCoffeePrice.text.toString().toDoubleOrNull()

            if (name.isNotEmpty() && price != null) {
                dbHelper.insertCoffee(name, price)
                updateRecyclerView()
                binding.etCoffeeName.text.clear()
                binding.etCoffeePrice.text.clear()
            }
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        updateRecyclerView()
    }

    private fun updateRecyclerView() {
        val coffeeList = dbHelper.getAllCoffees()
        binding.recyclerView.adapter = CoffeeAdapter(coffeeList)
    }
}
